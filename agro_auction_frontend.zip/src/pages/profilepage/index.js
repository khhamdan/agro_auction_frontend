import React from "react";
import VerticalTabs from "../../components/dashboardMyAccountformer/tabsDocuments";

export default function Usersdashboard() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <VerticalTabs />
    </div>
  );
}
