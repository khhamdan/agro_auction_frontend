import React from "react";
import DashboardUser from "../../components/dashboarduser";

export default function UserDashboard() {
  return (
    <div>
      <DashboardUser />
    </div>
  );
}
