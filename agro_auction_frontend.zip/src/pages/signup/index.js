import React from 'react';

import RegisterComponent from '../../components/login/register';

function Signup() {
  return (
    <div
      style={{
        backgroundColor: '#f5f5f5',
        height: '100vh',
      }}
    >
      <RegisterComponent />
    </div>
  );
}

export default Signup;
